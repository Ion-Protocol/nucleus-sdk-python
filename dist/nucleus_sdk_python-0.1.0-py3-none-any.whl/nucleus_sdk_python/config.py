address_book_endpoint = "https://api.nucleusearn.io/prod/address-book"
DEFAULT_BASE_URL = "https://api.nucleusearn.io/merkle/"
# DEFAULT_BASE_URL = " https://m6i5yq391e.execute-api.us-east-1.amazonaws.com/prod/"